﻿Imports System
Imports System.IO


Public Class FrmMain

    Private Sub FrmMain_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim hc As New HtmlCapture()
        AddHandler hc.HtmlImageCapture, AddressOf hc_HtmlImageCapture

        hc.Create("g:\3.htm")
        ''or
        'hc.Create("http://www.codeproject.com", New Size(200, 300))
    End Sub

    Private Sub hc_HtmlImageCapture(sender As Object, url As Uri, image As Bitmap)
        image.Save("G:\HTMLToImage.png")


    End Sub

    Private ReadOnly Property ParentDirectory() As String
        Get
            Dim dir As New DirectoryInfo(Application.StartupPath)
            Return dir.Parent.FullName
        End Get
    End Property

    Private ReadOnly Property OutputDirectory() As String
        Get
            Dim dir As New DirectoryInfo(Application.StartupPath)
            Return dir.Parent.FullName + "\Output\"
        End Get
    End Property
End Class
