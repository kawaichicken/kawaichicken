﻿Imports System.Windows.Forms
Imports System.Drawing

Public Class HtmlCapture

    Private _Web As WebBrowser
    Private _Timer As Timer
    Private _Screen As Rectangle
    Private _ImgSize As System.Nullable(Of Size) = Nothing

    'an event that triggers when the html document is captured
    Public Delegate Sub HtmlCaptureEvent(sender As Object, url As Uri, image As Bitmap)
    Public Event HtmlImageCapture As HtmlCaptureEvent

    'class constructor
    Public Sub New()
        'initialise the webbrowser and the timer
        _web = New WebBrowser()
        _Timer = New Timer()
        _Timer.Interval = 2000
        _Screen = Screen.PrimaryScreen.Bounds
        'set the webbrowser width and hight
        _web.Width = _Screen.Width
        _web.Height = _Screen.Height
        'suppress script errors and hide scroll bars
        _web.ScriptErrorsSuppressed = True
        _web.ScrollBarsEnabled = False

        'attached events
        AddHandler _web.Navigating, AddressOf web_Navigating
        AddHandler _web.DocumentCompleted, AddressOf web_DocumentCompleted
        AddHandler _Timer.Tick, AddressOf tready_Tick
    End Sub

#Region "Public methods"
    Public Sub Create(url As String)
        _ImgSize = Nothing
        _web.Navigate(url)
    End Sub

    Public Sub Create(url As String, imgsz As Size)
        Me._ImgSize = imgsz
        _web.Navigate(url)
    End Sub
#End Region

#Region "Events"
    Private Sub web_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs)
        'start the timer
        _Timer.Start()
    End Sub

    Private Sub web_Navigating(sender As Object, e As WebBrowserNavigatingEventArgs)
        'stop the timer   
        _Timer.[Stop]()
    End Sub

    Private Sub tready_Tick(sender As Object, e As EventArgs)
        'stop the timer
        _Timer.[Stop]()
        'get the size of the document's body
        Dim body As Rectangle = _Web.Document.Body.ScrollRectangle

        'check if the document width/height is greater than screen width/height
        Dim docRectangle As New Rectangle() With { _
         .Location = New Point(0, 0), _
         .Size = New Size(If(body.Width > _Screen.Width, body.Width, _Screen.Width), If(body.Height > _Screen.Height, body.Height, _Screen.Height)) _
        }
        'set the width and height of the WebBrowser object
        _Web.Width = docRectangle.Width
        _Web.Height = docRectangle.Height

        'if the imgsize is null, the size of the image will 
        'be the same as the size of webbrowser object
        'otherwise  set the image size to imgsize
        Dim imgRectangle As Rectangle
        If _ImgSize Is Nothing Then
            imgRectangle = docRectangle
        Else
            imgRectangle = New Rectangle() With { _
             .Location = New Point(0, 0), _
             .Size = _ImgSize.Value _
            }
        End If
        'create a bitmap object 
        Dim bitmap As New Bitmap(imgRectangle.Width, imgRectangle.Height)
        'get the viewobject of the WebBrowser
        Dim ivo As IViewObject = TryCast(_Web.Document.DomDocument, IViewObject)

        Using g As Graphics = Graphics.FromImage(bitmap)
            'get the handle to the device context and draw
            Dim hdc As IntPtr = g.GetHdc()
            ivo.Draw(1, -1, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, hdc, _
             imgRectangle, docRectangle, IntPtr.Zero, 0)
            g.ReleaseHdc(hdc)
        End Using

        'invoke the HtmlImageCapture event
        RaiseEvent HtmlImageCapture(Me, _Web.Url, bitmap)
    End Sub
#End Region

End Class
